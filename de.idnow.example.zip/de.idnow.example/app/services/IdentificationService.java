package services;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import models.Identification;

public class IdentificationService {
	private static IdentificationService identificationService;
	private Map<Integer, Identification> identifications = new HashMap<>();

	public static IdentificationService getInstance() {
		if (identificationService == null) {
			identificationService = new IdentificationService();
		}
		return identificationService;
	}

	public Identification startIdentification(Identification identification) {
		int id = identifications.size() + 1;
		identification.setId(id);
		identifications.put(identification.getId(), identification);
		return identification;
	}

	public Identification getIdentification(int id) {
		return identifications.get(id);
	}

	public Set<Identification> getAllIdentifications() {
		return new HashSet<>(identifications.values());
	}

	public Identification updateIdentification(Identification identification) {
		int id = identification.getId();
		if (identifications.containsKey(id)) {
			identifications.put(id, identification);
			return identification;
		}
		return null;
	}

	public boolean deleteIdentification(int id) {
		return identifications.remove(id) != null;
	}
}
