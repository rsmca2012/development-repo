package services;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import models.Company;

public class CompanyService {
	private static CompanyService companyService;
	private Map<Integer, Company> companies = new HashMap<>();

	public static CompanyService getInstance() {
		if (companyService == null) {
			companyService = new CompanyService();
		}
		return companyService;
	}

	public Company addCompany(Company company) {
		int id = companies.size() + 1;
		company.setId(id);
		companies.put(id, company);
		return company;
	}

	public Company getCompany(int id) {
		return companies.get(id);
	}

	public Set<Company> getAllCompanies() {
		return new HashSet<>(companies.values());
	}

	public Company updateCompany(Company company) {
		int id = company.getId();
		if (companies.containsKey(id)) {
			companies.put(id, company);
			return company;
		}
		return null;
	}

	public boolean deleteCompany(int id) {
		return companies.remove(id) != null;
	}

}
