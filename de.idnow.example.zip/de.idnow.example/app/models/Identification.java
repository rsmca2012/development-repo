package models;

public class Identification {
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getTime() {
		return time;
	}
	public void setTime(Long time) {
		this.time = time;
	}
	public int getWaiting_time() {
		return waiting_time;
	}
	public void setWaiting_time(int wating_time) {
		waiting_time = wating_time;
	}
	public int getCompanyid() {
		return companyid;
	}
	public void setCompanyid(int companyId) {
//		Instant instant = Instant.ofEpochSecond(unixTimestamp);
//		Long time = instant.get
		this.companyid = companyId;
	}
	private int id;
	private String name;
	private Long time;
	private int waiting_time;
	private int companyid;
}
