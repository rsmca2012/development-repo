package models;

public class Company{
	
	public Company() {
		
	}

	public Company(int id, String name, int sLA_time, float sLA_percentage, float current_SLA_percentage) {
		this.id = id;
		this.name = name;
		this.sla_time = sLA_time;
		this.sla_percentage = sLA_percentage;
		this.current_sla_percentage = current_SLA_percentage;
	}
	private int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSla_time() {
		return sla_time;
	}
	public void setSla_time(int sLA_time) {
		sla_time = sLA_time;
	}
	public float getSla_percentage() {
		return sla_percentage;
	}
	public void setSla_percentage(float sLA_percentage) {
		sla_percentage = sLA_percentage;
	}
	@Override
	public String toString() {
		return "Company [id=" + id + ", name=" + name + ", sla_time=" + sla_time + ", sla_percentage=" + sla_percentage
				+ ", current_sla_percentage=" + current_sla_percentage + "]";
	}

	public float getCurrent_sla_percentage() {
		return current_sla_percentage;
	}
	public void setCurrent_sla_percentage(float current_SLA_percentage) {
		this.current_sla_percentage = current_SLA_percentage;
	}
	private String name;
	private int sla_time;
	private float sla_percentage;
	private float current_sla_percentage;
}
