package controllers;

import static java.util.Collections.sort;
import static play.libs.Json.fromJson;
import static play.libs.Json.toJson;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.databind.JsonNode;

import models.Company;
import models.Identification;
import play.libs.Json;
import play.mvc.*;
import services.CompanyService;
import services.IdentificationService;

public class RestController extends Controller {

	public Result startIdentification() {
		// Get the parsed JSON data
		JsonNode json = request().body().asJson();
		// Do something with the identification
		if (json == null) {
			return badRequest("Expecting Json Data");

		}
		IdentificationService.getInstance().startIdentification(fromJson(json, Identification.class));
		return ok();
	}

	public Result addCompany() {
		JsonNode json = request().body().asJson();
		if (json == null) {
			return badRequest("Expecting Json Data");

		}
		Company company = CompanyService.getInstance().addCompany(fromJson(json, Company.class));
		return ok(toJson(company));
	}

	public Result identifications() {
		JsonNode identifications = Json.newArray();
		Set<Identification> allIdentifications = IdentificationService.getInstance().getAllIdentifications();

		List<Identification> identificationList = new ArrayList<Identification>();
		identificationList.addAll(allIdentifications);

		sort(identificationList, getIdentificationSLAComparator());
		sort(identificationList, getIdentificationWatingTimeComparator());
		sort(identificationList, getIdentificationCurrentSLAPercentageComparator());

		identifications = toJson(identificationList.toArray());
		return ok(identifications);
	}

	public Result pendingIdentifications() {
		JsonNode identifications = Json.newArray();
		List<Identification> identificationsList = new ArrayList<Identification>();
		identificationsList.addAll(IdentificationService.getInstance().getAllIdentifications());

		sort(identificationsList, getIdentificationSLAComparator());
		sort(identificationsList, getIdentificationWatingTimeComparator());
		sort(identificationsList, getIdentificationCurrentSLAPercentageComparator());

		identifications = toJson(identificationsList.toArray());

		return ok(identifications);
	}

	private Comparator<Identification> getIdentificationSLAComparator() {
		Comparator<Identification> slaComparator = new Comparator<Identification>() {

			@Override
			public int compare(Identification o1, Identification o2) {
				Company companyIdentification1 = null;
				Company companyIdentification2 = null;

				if (o1.getCompanyid() > 0) {
					companyIdentification1 = CompanyService.getInstance().getCompany(o1.getCompanyid());
				}
				if (o2.getCompanyid() > 0) {
					companyIdentification2 = CompanyService.getInstance().getCompany(o2.getCompanyid());
				}
				int company1Slatime = companyIdentification1 == null ? 0 : companyIdentification1.getSla_time();
				int company2Slatime = companyIdentification2 == null ? 0 : companyIdentification2.getSla_time();

				return Integer.compare(company1Slatime, company2Slatime);
			}
		};

		return slaComparator;
	}

	private Comparator<Identification> getIdentificationCurrentSLAPercentageComparator() {
		Comparator<Identification> slaPercentageComparator = new Comparator<Identification>() {

			@Override
			public int compare(Identification o1, Identification o2) {
				Company companyIdentification1 = null;
				Company companyIdentification2 = null;

				if (o1.getCompanyid() > 0) {
					companyIdentification1 = CompanyService.getInstance().getCompany(o1.getCompanyid());
				}
				if (o2.getCompanyid() > 0) {
					companyIdentification2 = CompanyService.getInstance().getCompany(o2.getCompanyid());
				}
				float company1SlaCurrentPercentage = companyIdentification1 == null ? 0.0f
						: companyIdentification1.getCurrent_sla_percentage();
				float company2SlaCurrentPercentage = companyIdentification2 == null ? 0.0f
						: companyIdentification2.getCurrent_sla_percentage();

				return Float.compare(company1SlaCurrentPercentage, company2SlaCurrentPercentage);
			}
		};
		return slaPercentageComparator;

	}

	private Comparator<Identification> getIdentificationWatingTimeComparator() {
		Comparator<Identification> waitingTimeComparator = new Comparator<Identification>() {

			@Override
			public int compare(Identification o1, Identification o2) {
				if (o1.getWaiting_time() > o2.getWaiting_time()) {
					return -1;
				} else if (o1.getWaiting_time() < o2.getWaiting_time()) {
					return 1;
				}
				return 0;
			}
		};
		return waitingTimeComparator;
	}
}
