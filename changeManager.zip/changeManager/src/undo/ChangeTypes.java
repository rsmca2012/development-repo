package undo;

public enum ChangeTypes {

	DELETION_CHANGETYPE("Delete"), INSERTION_CHANGETYPE("Insert");
	private String type;

	private ChangeTypes(final String changeTypes) {
		type = changeTypes;
	}

	public String getType() {
		return type;
	}
}
