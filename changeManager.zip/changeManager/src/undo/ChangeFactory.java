package undo;

public interface ChangeFactory {

	public Change registerInsertion(int pos, String s, int oldDot, int newDot);
	public Change registerDeletion(int pos, String s, int oldDot, int newDot);
}
