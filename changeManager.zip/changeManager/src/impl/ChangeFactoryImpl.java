package impl;

import undo.Change;
import undo.ChangeFactory;

public class ChangeFactoryImpl implements ChangeFactory {

	@Override
	public Change registerInsertion(int pos, String s, int oldDot, int newDot) {
		return new InsertionImpl(pos, s, oldDot, newDot);
	}

	@Override
	public Change registerDeletion(int pos, String s, int oldDot, int newDot) {
		return new DeletionImpl(pos, s, oldDot, newDot);
	}

}
