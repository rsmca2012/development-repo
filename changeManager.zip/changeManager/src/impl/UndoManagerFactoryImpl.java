package impl;

import undo.Document;
import undo.UndoManager;
import undo.UndoManagerFactory;

public class UndoManagerFactoryImpl implements UndoManagerFactory {

	@Override
	public UndoManager createUndoManager(Document doc, int bufferSize) {
		validateUndoManager(doc, bufferSize);
		return new UndoManagerImpl(doc, bufferSize);
	}

	void validateUndoManager(Document doc, int bufferSize) {
		if (doc == null) {
			throw new IllegalArgumentException("Document cannot be empty");
		}
		if (bufferSize == 0) {
			throw new IllegalArgumentException("Size cannot be empty");
		}
	}

}
