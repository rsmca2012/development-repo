package impl;

import java.util.LinkedList;

import undo.Change;
import undo.Document;
import undo.UndoManager;

public class UndoManagerImpl implements UndoManager {

	private final Document document;
	private final int changeSize;
	private final LinkedList<Change> changeList;
	private int undoLevel;
	private boolean canRedo = false;

	public UndoManagerImpl(final Document doc, final int bufferSize) {
		document = doc;
		changeSize = bufferSize;
		changeList = new LinkedList<Change>();
	}

	@Override
	public void registerChange(Change change) {
		if (changeList.size() < changeSize) {
			changeList.addFirst(change);
		} else {
			System.out.println("Size exhausted. Removing last entry: " + changeList.removeLast().toString());
			changeList.addFirst(change);
		}
		resetUndoLevel();

	}

	private void resetUndoLevel() {
		undoLevel = 0;
		canRedo = false;
	}

	@Override
	public boolean canUndo() {
		return changeList.size() > 0;
	}

	@Override
	public void undo() {
		if (!canUndo())
			throw new IllegalStateException("Nothing to Undo");

		if (undoLevel == changeList.size())
			throw new IllegalStateException("Reached end of Undo Buffer");

		changeList.get(undoLevel).revert(document);
		/*
		 * If undo is called before a new change is registered then this will lead to
		 * the next change in the stack to be undone
		 */
		undoLevel++;
		canRedo = true;
	}

	@Override
	public boolean canRedo() {
		return canRedo;
	}

	@Override
	public void redo() {
		if (!canRedo())
			throw new IllegalStateException("Nothing to Redo");

		undoLevel--;
		if (undoLevel < 0)
			throw new IllegalStateException("Reached end of Redo Buffer");
		changeList.get(undoLevel).apply(document);

	}

}
