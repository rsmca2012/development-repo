package impl;

import undo.Change;
import undo.ChangeTypes;
import undo.Document;

public class InsertionImpl implements Change  {
	private final int pos;
    private final String changeString;
    private final int oldDot;
    private final int newDot;
    
    public InsertionImpl(final int pos, final String s, final int oldDot, final int newDot) {
        this.pos = pos;
        this.changeString = s;
        this.oldDot = oldDot;
        this.newDot = newDot;
    }
    
    
	@Override
	public void apply(Document doc) {
		  doc.insert(pos, changeString);
	        doc.setDot(newDot);
		
	}
	@Override
	public void revert(Document doc) {
		  doc.delete(pos, changeString);
	        doc.setDot(oldDot);
		
	}


	@Override
	public String getType() {
		return ChangeTypes.INSERTION_CHANGETYPE.getType();
	}
	
	@Override
    public String toString() {
        return "InsertionImpl{" +
                "changeString='" + changeString + '\'' +
                '}';
    }

}
