package impl;

import undo.Document;

public class DocumentImpl implements Document {

	@Override
	public void delete(int pos, String s) {
		System.out.println("Deleting in document" + s);
		
	}

	@Override
	public void insert(int pos, String s) {
		System.out.println("Inserting in document" + s);
		
	}

	@Override
	public void setDot(int pos) {
		System.out.println("Setting cursor in document at" + pos);
		
	}

}
